import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import Patient from "./models/Patient.js";

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: "http://localhost:5000" }));
app.use(express.json());

// MongoDB Connection
mongoose.connect("mongodb://localhost:27017/Hospital")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Root Route
app.get("/", (req, res) => {
  res.send("Patient Record Management System API");
});

// Insert a Patient
app.post("/api/patients", async (req, res) => {
  try {
    // Generate PID (e.g., P001, P002...)
    const count = await Patient.countDocuments();
    const PID = `P${(count + 1).toString().padStart(3, "0")}`;
    
    // Normalize field names to match schema
    const patientData = {
      FirstName: req.body.FirstName,
      LastName: req.body.LastName,
      Email: req.body.Email,
      NearCity: req.body.NearCity,
      Doctor: req.body.Doctor,
      Guardian: req.body.Guardian,
      Status: req.body.Status,
      LastVisitDate: req.body.LastVisitDate,
      MedicalConditions: req.body.MedicalConditions || [],
      Medications: req.body.Medications || [],
      Allergies: req.body.Allergies || [],
      PID
    };

    const patient = new Patient(patientData);
    await patient.save();
    res.status(201).json(patient);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Show all Patients
app.get("/api/patients", async (req, res) => {
  try {
    const patients = await Patient.find();
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find a Patient by PID
app.get("/api/patients/pid/:pid", async (req, res) => {
  try {
    const patient = await Patient.findOne({ PID: req.params.pid });
    if (!patient) return res.status(404).json({ error: "Patient not found" });
    res.json(patient);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patient by First Name
app.get("/api/patients/firstname/:firstName", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      FirstName: new RegExp(`^${req.params.firstName}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patient by Last Name
app.get("/api/patients/lastname/:lastName", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      LastName: new RegExp(`^${req.params.lastName}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patients by Email
app.get("/api/patients/email/:email", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      Email: new RegExp(`^${req.params.email}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patients by Nearest City
app.get("/api/patients/city/:city", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      NearCity: new RegExp(`^${req.params.city}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patients by Assigned Doctor
app.get("/api/patients/doctor/:doctor", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      Doctor: new RegExp(`^${req.params.doctor}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Find Patients by Guardian
app.get("/api/patients/guardian/:guardian", async (req, res) => {
  try {
    const patients = await Patient.find({ 
      Guardian: new RegExp(`^${req.params.guardian}$`, 'i') 
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update Patient by PID
app.put("/api/patients/pid/:pid", async (req, res) => {
  try {
    const patient = await Patient.findOneAndUpdate(
      { PID: req.params.pid },
      req.body,
      { new: true, runValidators: true }
    );
    if (!patient) return res.status(404).json({ error: "Patient not found" });
    res.json(patient);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update Patients by First Name (Consider limiting or removing)
app.put("/api/patients/firstname/:firstName", async (req, res) => {
  try {
    const result = await Patient.updateMany(
      { FirstName: new RegExp(`^${req.params.firstName}$`, 'i') },
      req.body,
      { runValidators: true }
    );
    res.json({ updated: result.modifiedCount });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete Patient by PID
app.delete("/api/patients/pid/:pid", async (req, res) => {
  try {
    const result = await Patient.deleteOne({ PID: req.params.pid });
    if (result.deletedCount === 0) return res.status(404).json({ error: "Patient not found" });
    res.json({ message: "Patient deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});