import mongoose from "mongoose";

const patientSchema = new mongoose.Schema({
  PID: { type: String, required: true, unique: true },
  FirstName: { type: String, required: true },
  LastName: { type: String, required: true },
  Email: { type: String, trim: true },
  NearCity: { type: String, required: true },
  Doctor: { type: String, required: true },
  Guardian: { type: String, trim: true },
  Status: { type: String, required: true, enum: ["Alive", "Deceased"] },
  LastVisitDate: { type: Date, required: true },
  MedicalConditions: [{ type: String, trim: true }],
  Medications: [{ type: String, trim: true }],
  Allergies: [{ type: String, trim: true }],
}, { timestamps: true });

export default mongoose.model("Patient", patientSchema);